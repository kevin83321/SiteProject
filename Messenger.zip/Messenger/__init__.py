# -*- encoding: UTF-8 -*-
# 初始化
# CopyRight : XIQICapital 希奇資本
# Author: Kevin Cheng 鄭圳宏
# Create: 2020.02.17
# Update: 2020.02.17
# Version: 1
# # TODO Initial